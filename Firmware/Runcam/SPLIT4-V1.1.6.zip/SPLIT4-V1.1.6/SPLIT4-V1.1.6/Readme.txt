HOW TO UPDATE?
The classic method (manually copy the firmware file onto the SD card).
Firmware Upgrade
1. After downloading the firmware, unzip the downloaded file, find the Split-4.BRN file and copy it to the root directory of the microSD card. The firmware name should be confirmed as Split-4.BRN.
2. Disconnect from the computer, powering the camera via the mobile charger. And then turn on the RUNCAM Split-4 with the micro SD card inserted. The camera will automatically update the firmware.
3. Orange light blinks slowly while firmware is upgrading.
4. After 1 minute, the camera will automatically shut down,upgrade has completed.
===========================================================================================
Split-4 Firmware V1.1.6
1.Fixed some bugs.

